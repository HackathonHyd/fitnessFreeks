package com.honeywell.fitness.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.honeywell.fitness.model.Coach;
import com.honeywell.fitness.model.User;

/**
 * @author Chandra Vardhan
 */
@Repository
public class UserDaoImpl implements UserDao  {

	@Autowired
    private SessionFactory sessionFactory;
	
	@Override
	public void registerUser(final User User) {
		this.sessionFactory.getCurrentSession().save(User);
	}

	

	@Override
	public boolean loginUser(final User user) {
		if(user == null)
			return false;
		User newUser = (User)this.sessionFactory.getCurrentSession().get(User.class,user.getId());
		if(newUser ==null) 
			return false;
		return true;
	}

	@Override
	public List<Coach> findCoaches(final String city) {
		if(city == null)
			return null;
		Session currentSession = this.sessionFactory.openSession();
		if(currentSession != null) {
			String query = "select * from Coach where city ='" +city+"'";
			Query query2 = currentSession.createSQLQuery(query);
			List list = query2.list();
			if(list != null && !list.isEmpty()) {
				return list;
			}
		}
		return null;
	}

	@Override
	public List<String> getGoals(final User user) {
		if(user == null)
			return null;
		Session currentSession = this.sessionFactory.openSession();
		List<String> list1 = new ArrayList<String>();
		list1.add("G1");
		if(list1 != null)
		return list1;
		if(currentSession != null) {
			String query = "select * from Goals ";
			Query query2 = currentSession.createSQLQuery(query);
			List list = query2.list();
			if(list != null && !list.isEmpty()) {
				return list;
			}
		}
		return null;
	}	

}
