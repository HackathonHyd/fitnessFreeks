package com.honeywell.fitness.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.honeywell.fitness.dao.UserDao;
import com.honeywell.fitness.model.Coach;
import com.honeywell.fitness.model.User;

/**
 * @author Chandra Vardhan
 */
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
    private UserDao userDAO;

	@Override
	@Transactional
	public void registerUser(final User user) {
		userDAO.registerUser(user);
	}
	
	public List<String> getGoals(final User user) {
		return userDAO.getGoals(user);
	}
	@Override
	public boolean loginUser(final User user) {
		return userDAO.loginUser(user);
	}

	@Override
	public List<Coach> findCoaches(final String city) {
		return userDAO.findCoaches(city);
	}	
}
