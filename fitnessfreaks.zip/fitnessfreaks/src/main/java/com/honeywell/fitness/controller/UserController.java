package com.honeywell.fitness.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.honeywell.fitness.model.User;
import com.honeywell.fitness.service.UserService;


/**
 * @author Chandra Vardhan
 */
@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	public void setuserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String defaultPage(ModelMap map) {
		return "redirect:/list";
	}
	

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String registerUser(
			@ModelAttribute(value = "user") User user,
			BindingResult result) {
		userService.registerUser(user);
		return "redirect:/list";
	}

	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginUser(
			@ModelAttribute(value = "user") User user,
			BindingResult result) {
		userService.loginUser(user);
		return "redirect:/list";
	}

	@RequestMapping(value = "/findCoaches/{city}", method = RequestMethod.POST)
	public String findCoaches(@PathVariable("city")  String city) {
		userService.findCoaches(city);
		return "redirect:/list";
	}

	@RequestMapping(value = "/getGoals", method = RequestMethod.POST)
	public String getGoals(
			@ModelAttribute(value = "user") User user,
			BindingResult result) {
		userService.getGoals(user);
		return "redirect:/list";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(ModelMap model) {
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(ModelMap model) {
		return "logout";
	}
}
