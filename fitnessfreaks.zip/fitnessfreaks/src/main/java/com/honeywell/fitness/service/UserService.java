package com.honeywell.fitness.service;

import java.util.List;

import com.honeywell.fitness.model.Coach;
import com.honeywell.fitness.model.User;

/**
 * @author Chandra Vardhan
 */
public interface UserService {
	
	void registerUser(final User user);

	boolean loginUser(final User user);

	List<Coach> findCoaches(final String city);
	
	List<String> getGoals(final User user);
	
}
