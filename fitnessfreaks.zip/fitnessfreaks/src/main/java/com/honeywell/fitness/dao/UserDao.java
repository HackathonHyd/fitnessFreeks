package com.honeywell.fitness.dao;

import java.util.List;

import com.honeywell.fitness.model.Coach;
import com.honeywell.fitness.model.User;

/**
 * @author Chandra Vardhan
 */
public interface UserDao {
	
	public void registerUser(User user);

	public boolean loginUser(User user);

	public List<Coach> findCoaches(String city);
	
	public List<String> getGoals(User user);
	
}